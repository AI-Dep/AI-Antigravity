# Tests package for Fixed Asset AI
